/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author Shakthi
 */
public class OrderDetail {
	private String room;
        private float total;

	public OrderDetail(String room, String total) {
		this.room = room;
		this.total = Float.parseFloat(total);
	}
        
        public String getRoom() {
            return room;
        }
        
        public String getTotal() {
		return String.format("%.2f", total);
	}
}
