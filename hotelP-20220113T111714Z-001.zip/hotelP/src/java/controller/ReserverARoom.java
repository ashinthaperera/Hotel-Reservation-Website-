
package controller;

import com.paypal.base.rest.PayPalRESTException;
import common.Db_connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "ReserverARoom", urlPatterns = {"/ReserverARoom"})
public class ReserverARoom extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          
        String current_user_val = request.getParameter("current_user");
        String CheckIn_val = request.getParameter("CheckIn");
        String CheckOut_val = request.getParameter("CheckOut");
        String Adults_val = request.getParameter("Adults");
        String Kids_val = request.getParameter("Kids");
        String room = "Room";
        float total = ((Integer.parseInt(Kids_val) * 20) + (Integer.parseInt(Adults_val) * 10));
        
        OrderDetail orderDetail = new OrderDetail(room, String.format("%.2f", total));

                try {
                PaymentServices paymentServices = new PaymentServices();
                String approvalLink = paymentServices.authorizePayment(orderDetail);

                response.sendRedirect(approvalLink);

		} catch (PayPalRESTException ex) {
			request.setAttribute("errorMessage", ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
//        try {
//                PaymentServices paymentServices = new PaymentServices();
//                String approvalLink = paymentServices.authorizePayment(orderDetail);
//
//                response.sendRedirect(approvalLink);
//
//        } catch (PayPalRESTException ex) {
//                request.setAttribute("errorMessage", ex.getMessage());
//                ex.printStackTrace();
//                request.getRequestDispatcher("error.jsp").forward(request, response);
//        }
//        processRequest(request, response);
//        PrintWriter out = response.getWriter();
//        try {
//        	String current_user_val = request.getParameter("current_user");
//            String CheckIn_val = request.getParameter("CheckIn");
//            String CheckOut_val = request.getParameter("CheckOut");
//            String Adults_val = request.getParameter("Adults");
//            String Kids_val = request.getParameter("Kids");
//            
//                Db_connection obj_DB_Connection = new Db_connection();
//                Connection connection = obj_DB_Connection.get_connection();
//                PreparedStatement ps = null;
//
//                 String sql = "insert into rooms (CheckIn, CheckOut, Adults,Kids,Status,RoomNo,RequestMadeBy) values(?,?,?,?,?,?,?)";
//                Class.forName("com.mysql.jdbc.Driver");
//                
//                ps = connection.prepareStatement(sql);
//                ps.setString(1, CheckIn_val);
//                ps.setString(2, CheckOut_val);
//                ps.setString(3, Adults_val);
//                ps.setString(4, Kids_val);
//                ps.setString(5, "0");
//                ps.setString(6, null);
//                ps.setString(7, current_user_val);
//              
//         
//             
//                
//                ps.executeUpdate();
//                out.println("<script type=\"text/javascript\">");
//                out.println("alert('Request Success !');");
//                out.println("location='user.jsp';");
//                out.println("</script>");
//
//
//        } catch (SQLException ex) {
//            out.println(ex);
//        } catch (ClassNotFoundException ex) {
//            out.println(ex);
//        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
