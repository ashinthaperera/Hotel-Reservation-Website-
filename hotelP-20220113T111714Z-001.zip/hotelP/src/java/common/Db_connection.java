
package common;

import java.sql.Connection;
import java.sql.DriverManager;


public class Db_connection {
    public static void main(String[] args) {
		Db_connection obj_DB_Connection = new Db_connection();
		System.out.println(obj_DB_Connection.get_connection());
	}

	public Connection get_connection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelxyz", "root", "");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
}
